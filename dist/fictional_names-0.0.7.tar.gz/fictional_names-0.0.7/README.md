# Fictional Names

A Python project to generate fictional names.