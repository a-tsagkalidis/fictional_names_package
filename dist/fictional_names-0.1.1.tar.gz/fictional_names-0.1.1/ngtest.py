from fictional_names import name_generator
names = name_generator.generate_name

print(names())