### fictional_names
a name generator tailored for fictional games.